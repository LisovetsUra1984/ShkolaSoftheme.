﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_1
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Hello World");
            Console.WriteLine("This program lists all the files in the directory:");
            Console.WriteLine("Ura:");
            string sName = Console.ReadLine();
            Console.WriteLine("Привет, " + sName);
            Console.WriteLine("Нажмите ENTER что бы выйти из программы");
            Console.Read();
            

            }
            

            }

        }
    
    

